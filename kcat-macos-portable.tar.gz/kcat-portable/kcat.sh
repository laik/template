#!/bin/bash
# Wrapper script for kcat that sets the library path

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DYLD_LIBRARY_PATH="${SCRIPT_DIR}/lib:$DYLD_LIBRARY_PATH"

"${SCRIPT_DIR}/kcat" "$@"