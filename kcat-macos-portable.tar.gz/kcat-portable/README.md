# kcat Portable Package

This package contains a portable version of kcat for macOS that can be run on different machines.

## Contents

- `kcat`: The kcat binary
- `lib/`: Directory containing the required dynamic libraries
- `kcat.sh`: Wrapper script that sets the library path correctly

## Usage

Run kcat using the wrapper script:

```
./kcat.sh -h
```

The wrapper script automatically sets the `DYLD_LIBRARY_PATH` to point to the included libraries.

## Requirements

This package requires macOS with ARM64 architecture.