# tmux Static Build Instructions

## 构建静态链接的 tmux

这个版本的 tmux 已经静态链接了以下库：
- libevent
- ncurses
- utf8proc

只依赖 macOS 系统库：
- libSystem.B.dylib (系统核心库)
- libresolv.9.dylib (DNS 解析库)

这两个库在所有 macOS 系统上都存在，因此可以在离线机器上直接运行。

## 构建命令

```bash
# 1. 生成 configure 脚本
./autogen.sh

# 2. 配置构建
./configure --enable-utf8proc \
  LDFLAGS="-L/opt/homebrew/Cellar/utf8proc/2.11.0/lib \
           -L/opt/homebrew/Cellar/libevent/2.1.12_1/lib \
           -L/opt/homebrew/Cellar/ncurses/6.5/lib"

# 3. 编译（使用静态库）
make LIBS="/opt/homebrew/Cellar/utf8proc/2.11.0/lib/libutf8proc.a \
           /opt/homebrew/Cellar/ncurses/6.5/lib/libncurses.a \
           /opt/homebrew/Cellar/libevent/2.1.12_1/lib/libevent_core.a \
           -lm -lresolv" -j4
```

## 验证依赖

```bash
# 查看动态库依赖
otool -L tmux

# 应该只显示：
# /usr/lib/libSystem.B.dylib
# /usr/lib/libresolv.9.dylib
```

## 文件大小

静态链接版本约 1.6 MB，比动态链接版本 (1.1 MB) 稍大，但可以独立运行。

## 部署

直接将 `tmux` 二进制文件复制到目标机器即可使用：

```bash
# 复制到目标机器
scp tmux user@target-machine:/usr/local/bin/

# 或打包
tar czf tmux-static-macos-arm64.tar.gz tmux
```

## 注意事项

1. 此二进制文件仅适用于 **macOS ARM64 (Apple Silicon)** 架构
2. 如需 Intel 版本，需在 Intel Mac 上重新编译
3. 目标机器必须是 macOS 系统（不能在 Linux 上运行）
4. 系统版本兼容性取决于编译时使用的 SDK 版本

## 版本信息

- tmux version: next-3.6
- Build date: $(date)
- Architecture: arm64 (Apple Silicon)
