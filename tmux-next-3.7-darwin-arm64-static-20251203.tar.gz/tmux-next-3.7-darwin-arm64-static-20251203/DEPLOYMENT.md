# tmux Deployment Guide for Offline Systems

## Quick Start

If you encounter "can't find terminfo database" error, follow this guide.

## Solution 1: Use Bundled Terminfo (Recommended)

The package includes a `terminfo` directory with essential terminal definitions.

### Installation Steps:

```bash
# 1. Extract the package
tar xzf tmux-*.tar.gz
cd tmux-*

# 2. Install tmux binary
sudo cp tmux /usr/local/bin/
sudo chmod +x /usr/local/bin/tmux

# 3. Install terminfo database (choose ONE method):

# Method A: User-local installation (No root required)
mkdir -p ~/.terminfo
cp -r terminfo/* ~/.terminfo/

# Method B: System-wide installation (Requires root)
sudo mkdir -p /usr/share/terminfo
sudo cp -r terminfo/* /usr/share/terminfo/

# Method C: Portable - use environment variable
export TERMINFO=/path/to/tmux-package/terminfo
# Add to ~/.zshrc or ~/.bashrc to make permanent:
echo 'export TERMINFO=/path/to/terminfo' >> ~/.zshrc

# 4. Verify installation
tmux -V
```

## Solution 2: Set TERM Variable

If terminfo is available but tmux can't find it:

```bash
# Use a simpler terminal type
export TERM=xterm-256color

# Or fall back to basic xterm
export TERM=xterm
```

## Solution 3: Use tmux with -L flag

Specify a different terminal:

```bash
tmux -L xterm-256color
```

## Troubleshooting

### Error: "can't find terminfo database"

**Cause**: tmux cannot locate terminal capability definitions.

**Solutions**:
1. Install bundled terminfo (see above)
2. Set `TERMINFO` environment variable
3. Copy terminfo from another Mac:
   ```bash
   # On source Mac
   tar czf terminfo.tar.gz -C /usr/share terminfo
   
   # On target Mac
   sudo tar xzf terminfo.tar.gz -C /usr/share/
   ```

### Error: "open terminal failed: not a terminal"

**Cause**: Running tmux in a non-TTY environment or nested tmux.

**Solutions**:
1. Exit existing tmux session first
2. Run from a real terminal (not IDE terminal)
3. Check if you're already in tmux: `echo $TMUX`

### Error: "protocol version mismatch"

**Cause**: Client and server versions don't match.

**Solution**:
```bash
tmux kill-server
tmux
```

## Environment Variables

Important environment variables for tmux:

```bash
# Specify terminfo database location
export TERMINFO=~/.terminfo

# Set terminal type
export TERM=tmux-256color

# Specify tmux socket location
export TMUX_TMPDIR=/tmp/tmux-$USER

# Add to your shell profile (~/.zshrc or ~/.bashrc)
echo 'export TERMINFO=~/.terminfo' >> ~/.zshrc
echo 'export TERM=xterm-256color' >> ~/.zshrc
```

## Verification

Test your installation:

```bash
# 1. Check tmux version
tmux -V

# 2. Check terminfo
infocmp tmux-256color

# 3. Create a test session
tmux new-session -d -s test "echo 'Test successful'; sleep 5"
tmux ls
tmux kill-session -t test

# 4. Interactive test
tmux
# Press Ctrl+b, then d to detach
```

## Package Contents

```
tmux-*/
├── tmux                  # Static binary
├── terminfo/            # Terminal capability database
│   ├── 73/              # screen terminals
│   ├── 74/              # tmux terminals  
│   └── 78/              # xterm terminals
├── tmux.conf.example    # Sample configuration
├── README.md            # Build documentation
├── INSTALL.txt          # Installation guide
└── SHA256SUMS          # Checksums
```

## System Requirements

- **OS**: macOS (Darwin)
- **Architecture**: ARM64 (Apple Silicon) or x86_64 (Intel)
- **Minimum macOS Version**: 10.13+ (depends on build SDK)
- **No additional dependencies required** (statically linked)

## Advanced: Creating Terminfo on Target System

If you can't bundle terminfo, create it on the target system:

```bash
# 1. Get terminfo source
# Download from: https://invisible-island.net/ncurses/

# 2. Or create minimal terminfo manually
cat > tmux.terminfo << 'EOF'
tmux|tmux terminal multiplexer,
    colors#256, cols#80, it#8, lines#24, pairs#32767,
    bel=^G, blink=\E[5m, bold=\E[1m, clear=\E[H\E[J,
    cup=\E[%i%p1%d;%p2%dH, dim=\E[2m, home=\E[H,
    ht=^I, ind=^J, invis=\E[8m, kcub1=\E[D, kcud1=\E[B,
    kcuf1=\E[C, kcuu1=\E[A, rev=\E[7m, rmso=\E[27m,
    rmul=\E[24m, setab=\E[4%p1%dm, setaf=\E[3%p1%dm,
    sgr0=\E[m, smso=\E[7m, smul=\E[4m,
EOF

tic -o ~/.terminfo tmux.terminfo
```

## Support

For issues, please check:
1. This deployment guide
2. tmux documentation: https://github.com/tmux/tmux/wiki
3. Terminal compatibility: `infocmp $TERM`
