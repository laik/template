#!/bin/bash
# Quick deployment script for offline systems
# Run this on the target machine after extracting the package

set -e

echo "=== tmux Quick Deployment Script ==="
echo

# Check if running from package directory
if [ ! -f "tmux" ]; then
    echo "❌ Error: tmux binary not found in current directory"
    echo "Please run this script from the extracted package directory"
    exit 1
fi

# 1. Install tmux binary
echo "1. Installing tmux binary..."
if [ -w "/usr/local/bin" ]; then
    cp tmux /usr/local/bin/
    chmod +x /usr/local/bin/tmux
    echo "✓ Installed to /usr/local/bin/tmux"
else
    echo "Installing to /usr/local/bin/ (requires sudo)..."
    sudo cp tmux /usr/local/bin/
    sudo chmod +x /usr/local/bin/tmux
    echo "✓ Installed to /usr/local/bin/tmux"
fi

# 2. Install terminfo database
echo
echo "2. Installing terminfo database..."
if [ -d "terminfo" ]; then
    mkdir -p ~/.terminfo
    cp -r terminfo/* ~/.terminfo/
    echo "✓ Terminfo installed to ~/.terminfo/"
    
    # Also try to install system-wide if we have permission
    if [ -w "/usr/share/terminfo" ]; then
        cp -r terminfo/* /usr/share/terminfo/ 2>/dev/null && \
            echo "✓ Terminfo also installed to /usr/share/terminfo/"
    fi
else
    echo "⚠ Warning: terminfo directory not found"
    echo "You may encounter 'can't find terminfo database' errors"
fi

# 3. Verify installation
echo
echo "3. Verifying installation..."
VERSION=$(/usr/local/bin/tmux -V 2>&1)
if [ $? -eq 0 ]; then
    echo "✓ $VERSION"
else
    echo "❌ Failed to run tmux"
    exit 1
fi

# 4. Setup environment (optional)
echo
echo "4. Setting up environment..."
SHELL_RC=""
if [ -n "$ZSH_VERSION" ]; then
    SHELL_RC=~/.zshrc
elif [ -n "$BASH_VERSION" ]; then
    SHELL_RC=~/.bashrc
fi

if [ -n "$SHELL_RC" ] && [ -f "$SHELL_RC" ]; then
    # Check if already configured
    if ! grep -q "TERMINFO.*terminfo" "$SHELL_RC" 2>/dev/null; then
        echo "export TERMINFO=~/.terminfo" >> "$SHELL_RC"
        echo "✓ Added TERMINFO to $SHELL_RC"
    else
        echo "✓ TERMINFO already configured in $SHELL_RC"
    fi
fi

# 5. Test tmux
echo
echo "5. Testing tmux..."
tmux new-session -d -s test-session "echo 'Test successful'; sleep 2" 2>/dev/null
if tmux ls 2>/dev/null | grep -q test-session; then
    echo "✓ Test session created successfully"
    tmux kill-session -t test-session 2>/dev/null
else
    echo "⚠ Warning: Failed to create test session"
    echo "Please check DEPLOYMENT.md for troubleshooting"
fi

echo
echo "=== Installation Complete! ==="
echo
echo "Usage:"
echo "  Start tmux:        tmux"
echo "  List sessions:     tmux ls"
echo "  Attach to session: tmux attach"
echo "  Help:              tmux --help"
echo
echo "Configuration:"
echo "  - Copy tmux.conf.example to ~/.tmux.conf to customize"
echo "  - See DEPLOYMENT.md for detailed documentation"
echo
echo "If you encounter 'can't find terminfo database' error:"
echo "  export TERMINFO=~/.terminfo"
echo "  # Or add to your shell profile: echo 'export TERMINFO=~/.terminfo' >> ~/.zshrc"
echo
